package com.example.listview1309;

public class ItemChurrass {
    int id;
    String nome;
    int img;

    public ItemChurrass(int id, String nome, int img) {
        this.id = id;
        this.nome = nome;
        this.img = img;
    }
}
